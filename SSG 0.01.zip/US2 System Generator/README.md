# Godot-Gravity-Objects
A Godot 3 plugin that adds nodes that act like planets (they have gravity)
